module.exports = [
"[project]/.next-internal/server/app/(dashboard)/ticket-details/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_ticket-details_page_actions_0a5355f9.js.map