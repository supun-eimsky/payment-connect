module.exports = [
"[project]/.next-internal/server/app/(dashboard)/devices/view/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_devices_view_page_actions_e65c1ae0.js.map