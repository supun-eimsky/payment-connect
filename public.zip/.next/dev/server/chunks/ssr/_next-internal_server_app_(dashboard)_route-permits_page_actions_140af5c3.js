module.exports = [
"[project]/.next-internal/server/app/(dashboard)/route-permits/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_route-permits_page_actions_140af5c3.js.map