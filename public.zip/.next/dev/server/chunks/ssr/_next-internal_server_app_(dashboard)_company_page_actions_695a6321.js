module.exports = [
"[project]/.next-internal/server/app/(dashboard)/company/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_company_page_actions_695a6321.js.map