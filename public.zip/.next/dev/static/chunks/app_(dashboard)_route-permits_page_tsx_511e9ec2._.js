(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_31c9481d._.js",
  "static/chunks/node_modules_162ff332._.js"
],
    source: "dynamic"
});
