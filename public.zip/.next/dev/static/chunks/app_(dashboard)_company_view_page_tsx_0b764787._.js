(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1393238c._.js",
  "static/chunks/node_modules_a4c2d6d2._.js"
],
    source: "dynamic"
});
