(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_056b5081._.js",
  "static/chunks/node_modules_39eff00e._.js"
],
    source: "dynamic"
});
