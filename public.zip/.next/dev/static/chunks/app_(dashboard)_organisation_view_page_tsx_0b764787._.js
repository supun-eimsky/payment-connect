(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_59ad1b4a._.js",
  "static/chunks/node_modules_9cc76fb6._.js"
],
    source: "dynamic"
});
