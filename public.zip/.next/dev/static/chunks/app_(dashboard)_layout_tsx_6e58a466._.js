(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_6ee23e88._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_150b4c77._.js",
  "static/chunks/node_modules_react-icons_bs_index_mjs_8a44a60a._.js",
  "static/chunks/node_modules_react-icons_tb_index_mjs_c5ac7ced._.js",
  "static/chunks/node_modules_react-icons_pi_index_mjs_39252f67._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_sl_index_mjs_cb4be900._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_44feab80._.js"
],
    source: "dynamic"
});
