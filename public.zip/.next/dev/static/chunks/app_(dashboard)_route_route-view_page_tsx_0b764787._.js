(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_91815976._.js",
  "static/chunks/node_modules_0eea581f._.js",
  "static/chunks/node_modules_leaflet_dist_leaflet_ef5f0413.css"
],
    source: "dynamic"
});
