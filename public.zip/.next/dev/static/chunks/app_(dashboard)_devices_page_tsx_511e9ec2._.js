(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_fa0deebb._.js",
  "static/chunks/node_modules_69192f53._.js"
],
    source: "dynamic"
});
