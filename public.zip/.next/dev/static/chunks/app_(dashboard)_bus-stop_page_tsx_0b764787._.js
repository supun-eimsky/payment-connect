(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d515463e._.js",
  "static/chunks/node_modules_c4fd46e3._.js"
],
    source: "dynamic"
});
