(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f60a69a0._.js",
  "static/chunks/node_modules_ff9a5b56._.js"
],
    source: "dynamic"
});
