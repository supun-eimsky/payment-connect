(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_b0629b56._.js",
  "static/chunks/node_modules_f31f5604._.js"
],
    source: "dynamic"
});
