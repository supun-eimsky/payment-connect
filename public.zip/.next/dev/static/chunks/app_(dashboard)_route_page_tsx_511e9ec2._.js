(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_967ab7ee._.js",
  "static/chunks/node_modules_4cb69183._.js"
],
    source: "dynamic"
});
