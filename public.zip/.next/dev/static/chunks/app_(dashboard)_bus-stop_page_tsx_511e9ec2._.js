(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d515463e._.js",
  "static/chunks/node_modules_a83b8c9d._.js"
],
    source: "dynamic"
});
